/* ============================================
   Live AI Workflow — animated dashboard
   ============================================ */

// Stage icons
const IconDoc = ({ color = "#2F5D50" }) => (
  <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
    <path d="M7 4h10l4 4v16a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1Z" stroke={color} strokeWidth="1.4"/>
    <path d="M17 4v4h4" stroke={color} strokeWidth="1.4"/>
    <path d="M10 13h8M10 16h8M10 19h5" stroke={color} strokeWidth="1.4" strokeLinecap="round"/>
  </svg>
);
const IconParse = ({ color = "#2F5D50" }) => (
  <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
    <path d="M7 4h10l4 4v16a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1Z" stroke={color} strokeWidth="1.4"/>
    <path d="M17 4v4h4" stroke={color} strokeWidth="1.4"/>
    <path d="M10 14l2 2 5-5" stroke={color} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M10 20h8" stroke={color} strokeWidth="1.4" strokeLinecap="round"/>
  </svg>
);
const IconResearch = ({ color = "#2F5D50" }) => (
  <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
    <path d="M5 11l9-5 9 5" stroke={color} strokeWidth="1.4" strokeLinejoin="round"/>
    <path d="M6 11v10M22 11v10M10 13v6M14 13v6M18 13v6" stroke={color} strokeWidth="1.4"/>
    <path d="M4 22h20" stroke={color} strokeWidth="1.4" strokeLinecap="round"/>
  </svg>
);
const IconMatch = ({ color = "#2F5D50" }) => (
  <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
    <rect x="5" y="5" width="8" height="8" rx="1.4" stroke={color} strokeWidth="1.4"/>
    <rect x="15" y="5" width="8" height="8" rx="1.4" stroke={color} strokeWidth="1.4"/>
    <rect x="5" y="15" width="8" height="8" rx="1.4" stroke={color} strokeWidth="1.4"/>
    <rect x="15" y="15" width="8" height="8" rx="1.4" stroke={color} strokeWidth="1.4"/>
    <path d="M13 9h2M9 13v2M19 13v2M13 19h2" stroke={color} strokeWidth="1.4" strokeLinecap="round"/>
  </svg>
);
const IconWrite = ({ color = "#2F5D50" }) => (
  <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
    <path d="M4 22l4-1 12-12-3-3L5 18l-1 4Z" stroke={color} strokeWidth="1.4" strokeLinejoin="round"/>
    <path d="M15 7l3 3" stroke={color} strokeWidth="1.4"/>
  </svg>
);
const IconShield = ({ color = "#2F5D50" }) => (
  <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
    <path d="M14 4l9 3v7c0 5-4 9-9 10-5-1-9-5-9-10V7l9-3Z" stroke={color} strokeWidth="1.4" strokeLinejoin="round"/>
    <path d="M9 14l3 3 6-6" stroke={color} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);
const IconExport = ({ color = "#2F5D50" }) => (
  <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
    <path d="M7 4h10l4 4v16a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1Z" stroke={color} strokeWidth="1.4"/>
    <path d="M17 4v4h4" stroke={color} strokeWidth="1.4"/>
    <text x="14" y="22" textAnchor="middle" fontSize="6.5" fontWeight="700" fill={color} fontFamily="Inter">PDF</text>
  </svg>
);

const stages = [
  { n: "01", title: "RFP Upload",            sub: "Document received",       Icon: IconDoc },
  { n: "02", title: "RFP Parsing",           sub: "Extracting requirements", Icon: IconParse },
  { n: "03", title: "Client Research",       sub: "Gathering intelligence",  Icon: IconResearch },
  { n: "04", title: "Requirements Matching", sub: "Mapping capabilities",    Icon: IconMatch },
  { n: "05", title: "Proposal Writing",      sub: "Crafting proposal",       Icon: IconWrite },
  { n: "06", title: "Quality Review",        sub: "Validating completeness", Icon: IconShield },
  { n: "07", title: "PDF Export",            sub: "Preparing final document",Icon: IconExport },
];

/* ---------- Stage card ---------- */
const StageCard = ({ stage, idx, progress, status }) => {
  // status: 'pending' | 'active' | 'done'
  const isActive = status === 'active';
  const isDone = status === 'done';
  const isPending = status === 'pending';
  const Icon = stage.Icon;
  return (
    <div style={{
      position: 'relative',
      background: isActive
        ? 'linear-gradient(180deg, #FBF1D8 0%, #FAF7F2 100%)'
        : 'linear-gradient(180deg, rgba(255,255,255,0.95) 0%, rgba(250,247,242,0.85) 100%)',
      border: isActive
        ? '1.5px solid rgba(212, 168, 79, 0.55)'
        : '1px solid rgba(47, 93, 80, 0.08)',
      borderRadius: 16,
      padding: '14px 14px 16px',
      boxShadow: isActive
        ? '0 0 0 4px rgba(247, 231, 193, 0.55), 0 14px 30px rgba(212,168,79,0.18)'
        : '0 1px 2px rgba(35,69,57,0.04), 0 6px 18px rgba(35,69,57,0.06)',
      transition: 'all .6s cubic-bezier(.2,.7,.2,1)',
      minHeight: 168,
      display: 'flex',
      flexDirection: 'column',
    }}>
      {/* Number badge */}
      <div style={{
        position: 'absolute', top: 10, left: 10,
        background: isActive ? '#fff' : 'var(--sage-soft)',
        border: '1px solid rgba(47,93,80,0.12)',
        color: 'var(--forest-deep)',
        fontFamily: 'var(--f-display)',
        fontWeight: 600,
        fontSize: 11,
        padding: '3px 8px',
        borderRadius: 6,
        letterSpacing: '0.04em',
      }}>{stage.n}</div>

      {/* Active glow ping */}
      {isActive && (
        <span style={{
          position: 'absolute', top: 8, right: 12,
          width: 8, height: 8, borderRadius: '50%',
          background: 'var(--gold)',
          boxShadow: '0 0 0 4px rgba(212,168,79,0.18), 0 0 12px rgba(212,168,79,0.6)',
          animation: 'pulseGold 1.4s ease-in-out infinite',
        }}/>
      )}

      {/* Icon */}
      <div style={{ marginTop: 18, display: 'flex', justifyContent: 'center' }}>
        <Icon color={isPending ? '#8A958F' : '#2F5D50'} />
      </div>

      {/* Title */}
      <div style={{
        marginTop: 10, textAlign: 'center',
        fontFamily: 'var(--f-display)', fontWeight: 600, fontSize: 13.5,
        color: isPending ? 'var(--muted)' : 'var(--ink)',
        lineHeight: 1.2
      }}>{stage.title}</div>
      <div style={{
        marginTop: 3, textAlign: 'center',
        fontSize: 11, color: 'var(--muted)', lineHeight: 1.3
      }}>{stage.sub}</div>

      {/* Bottom strip: file / progress / check */}
      <div style={{ marginTop: 'auto', paddingTop: 12 }}>
        {idx === 0 ? (
          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '8px 10px',
            background: 'rgba(255,255,255,0.7)',
            border: '1px solid rgba(47,93,80,0.08)',
            borderRadius: 8,
            fontSize: 11
          }}>
            <div>
              <div style={{ fontWeight: 600, color: 'var(--ink)', fontSize: 11 }}>Hospital_RFP.pdf</div>
              <div style={{ color: 'var(--muted)', fontSize: 10 }}>38.4 MB</div>
            </div>
            <span style={{
              width: 16, height: 16, borderRadius: '50%',
              background: 'var(--forest)', display: 'grid', placeItems: 'center'
            }}>
              <svg width="9" height="9" viewBox="0 0 10 10"><path d="M2 5l2 2 4-4" stroke="#fff" strokeWidth="1.6" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
            </span>
          </div>
        ) : (
          <div>
            <div style={{
              height: 5, borderRadius: 999, background: 'rgba(47,93,80,0.08)',
              overflow: 'hidden', position: 'relative'
            }}>
              <div style={{
                width: `${progress}%`, height: '100%',
                background: isDone
                  ? 'linear-gradient(90deg, #3d7565, #2F5D50)'
                  : 'linear-gradient(90deg, #F0DBA6, #D4A84F)',
                borderRadius: 999,
                transition: 'width .4s linear',
                boxShadow: isActive ? '0 0 8px rgba(212,168,79,0.5)' : 'none'
              }}/>
            </div>
            <div style={{
              display: 'flex', justifyContent: 'flex-end',
              marginTop: 4, fontSize: 10, fontWeight: 600,
              color: isDone ? 'var(--forest)' : (isPending ? 'var(--muted)' : 'var(--gold-deep)')
            }}>{isPending ? 'Pending' : `${progress}%`}</div>
          </div>
        )}
      </div>
    </div>
  );
};

/* ---------- Workflow connections (SVG overlay) ---------- */
const Connections = ({ activeIdx }) => {
  // 7 stages in U-shape. Top row idx 0..3, bottom row idx 4..6 right-to-left visually.
  // We draw 6 segments between consecutive stages.
  return (
    <svg style={{
      position: 'absolute', inset: 0, width: '100%', height: '100%',
      pointerEvents: 'none', overflow: 'visible'
    }} preserveAspectRatio="none">
      <defs>
        <linearGradient id="connDone" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#D4A84F" stopOpacity="0.9"/>
          <stop offset="100%" stopColor="#D4A84F" stopOpacity="0.6"/>
        </linearGradient>
        <linearGradient id="connActive" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#D4A84F" stopOpacity="1"/>
          <stop offset="100%" stopColor="#F7E7C1" stopOpacity="0.9"/>
        </linearGradient>
      </defs>
      {/* segments rendered as absolutely positioned arrow lines via div CSS — see overlay below */}
    </svg>
  );
};

/* ---------- Mini sub-cards ---------- */
const ProposalPreviewCard = ({ progress }) => (
  <div style={{
    background: 'linear-gradient(180deg, rgba(255,255,255,0.92) 0%, rgba(250,247,242,0.85) 100%)',
    border: '1px solid rgba(47,93,80,0.08)',
    borderRadius: 14,
    padding: '14px 16px',
    display: 'flex', flexDirection: 'column', gap: 10
  }}>
    <div style={{ fontFamily: 'var(--f-display)', fontWeight: 600, fontSize: 13, color: 'var(--ink)' }}>
      Proposal Preview
    </div>
    <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
      {/* document mini */}
      <div style={{
        width: 52, height: 64, borderRadius: 4,
        background: '#fff',
        border: '1px solid rgba(47,93,80,0.12)',
        boxShadow: '0 4px 10px rgba(35,69,57,0.06)',
        position: 'relative',
        flexShrink: 0,
        padding: 6
      }}>
        <div style={{ height: 2, background: 'var(--forest)', width: '60%', borderRadius: 2, marginBottom: 4 }}/>
        {[0,1,2,3,4].map(i => (
          <div key={i} style={{
            height: 1.5, background: 'rgba(47,93,80,0.15)',
            width: `${[90, 85, 70, 80, 50][i]}%`,
            borderRadius: 2, marginBottom: 3
          }}/>
        ))}
        <div style={{
          position: 'absolute', top: -3, right: -3,
          width: 14, height: 14, borderRadius: '50%',
          background: 'var(--gold)', display: 'grid', placeItems: 'center',
          boxShadow: '0 2px 6px rgba(212,168,79,0.4)'
        }}>
          <svg width="8" height="8" viewBox="0 0 12 12"><path d="M6 1l1.5 3 3.3.4-2.4 2.3.6 3.3L6 8.5 3 10l.6-3.3L1.2 4.4 4.5 4 6 1Z" fill="#2A1E08"/></svg>
        </div>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontFamily: 'var(--f-display)', fontWeight: 600, fontSize: 12.5, color: 'var(--ink)' }}>
          Executive Summary
        </div>
        <div style={{ marginTop: 4 }}>
          {[88, 72, 90, 50].map((w, i) => (
            <div key={i} style={{
              height: 4, background: 'rgba(47,93,80,0.10)',
              width: `${w}%`, borderRadius: 2, marginBottom: 4
            }}/>
          ))}
        </div>
        <div style={{ marginTop: 6, fontSize: 10.5, color: 'var(--muted)' }}>
          {Math.round((progress/100) * 12)} of 12 sections generated
        </div>
      </div>
    </div>
    <div>
      <div style={{
        height: 4, borderRadius: 999, background: 'rgba(47,93,80,0.08)',
        overflow: 'hidden'
      }}>
        <div style={{
          width: `${progress}%`, height: '100%',
          background: 'linear-gradient(90deg, #3d7565, #2F5D50)',
          transition: 'width .4s linear'
        }}/>
      </div>
      <div style={{
        display: 'flex', justifyContent: 'space-between', marginTop: 4,
        fontSize: 10, color: 'var(--muted)'
      }}>
        <span>Drafting in progress</span>
        <span style={{ color: 'var(--forest)', fontWeight: 600 }}>{progress}%</span>
      </div>
    </div>
  </div>
);

const agentList = [
  { name: 'Orchestrator', Icon: IconShield },
  { name: 'Parser',       Icon: IconDoc },
  { name: 'Researcher',   Icon: IconResearch },
  { name: 'Matcher',      Icon: IconMatch },
  { name: 'Writer',       Icon: IconWrite },
  { name: 'Reviewer',     Icon: IconShield },
];

const AgentsActive = ({ activeAgent }) => (
  <div style={{
    background: 'linear-gradient(180deg, rgba(255,255,255,0.92) 0%, rgba(250,247,242,0.85) 100%)',
    border: '1px solid rgba(47,93,80,0.08)',
    borderRadius: 14,
    padding: '14px 16px',
    display: 'flex', flexDirection: 'column', gap: 12
  }}>
    <div style={{ fontFamily: 'var(--f-display)', fontWeight: 600, fontSize: 13, color: 'var(--ink)' }}>
      AI Agents Active
    </div>
    <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
      {agentList.map((a, i) => {
        const A = a.Icon;
        const isActive = i === activeAgent;
        return (
          <div key={i} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, flex: 1 }}>
            <div style={{
              width: 40, height: 40, borderRadius: '50%',
              background: isActive ? 'linear-gradient(180deg, #FBF1D8, #F0DBA6)' : '#fff',
              border: isActive ? '1.5px solid rgba(212,168,79,0.6)' : '1px solid rgba(47,93,80,0.10)',
              display: 'grid', placeItems: 'center',
              boxShadow: isActive
                ? '0 0 0 4px rgba(247, 231, 193, 0.5), 0 6px 14px rgba(212,168,79,0.25)'
                : '0 2px 6px rgba(35,69,57,0.05)',
              transition: 'all .5s ease'
            }}>
              <div style={{ transform: 'scale(0.7)' }}>
                <A color={isActive ? '#B88A2F' : '#2F5D50'} />
              </div>
            </div>
            <div style={{
              fontSize: 10, fontWeight: 600,
              color: isActive ? 'var(--gold-deep)' : 'var(--ink-soft)',
              fontFamily: 'var(--f-body)'
            }}>{a.name}</div>
          </div>
        );
      })}
    </div>
    <div style={{
      display: 'flex', alignItems: 'center', gap: 8,
      paddingTop: 10, borderTop: '1px dashed rgba(47,93,80,0.10)'
    }}>
      <span style={{
        width: 8, height: 8, borderRadius: '50%', background: 'var(--gold)',
        boxShadow: '0 0 8px rgba(212,168,79,0.7)',
        animation: 'pulseGold 1.4s ease-in-out infinite'
      }}/>
      <span style={{ fontSize: 11.5, color: 'var(--ink-soft)' }}>
        6 Agents working in harmony
      </span>
      {/* mini sparkline */}
      <svg width="120" height="14" viewBox="0 0 120 14" style={{ marginLeft: 'auto' }}>
        <path d="M0 9 Q 15 4, 30 8 T 60 7 T 90 9 T 120 5"
              stroke="#D4A84F" strokeWidth="1.3" fill="none" strokeLinecap="round"/>
        <circle cx="40" cy="7" r="2" fill="#D4A84F"/>
        <circle cx="80" cy="8.5" r="2" fill="#D4A84F"/>
        <circle cx="118" cy="5" r="2.5" fill="#D4A84F"/>
      </svg>
    </div>
  </div>
);

/* ---------- Arrow connector between cards ---------- */
const ArrowH = ({ active, done, direction = 'right' }) => (
  <div style={{
    position: 'absolute', top: '50%', transform: 'translateY(-50%)',
    [direction === 'right' ? 'right' : 'left']: -18,
    width: 36, height: 18,
    display: 'grid', placeItems: 'center',
    zIndex: 2, pointerEvents: 'none'
  }}>
    <svg width="36" height="18" viewBox="0 0 36 18">
      <line x1="2" y1="9" x2="28" y2="9"
            stroke={done || active ? '#D4A84F' : 'rgba(212,168,79,0.30)'}
            strokeWidth="1.5"
            strokeDasharray={done || active ? '0' : '3 3'}
            style={{ filter: active ? 'drop-shadow(0 0 4px rgba(212,168,79,0.6))' : 'none' }}/>
      <path d="M26 5 L32 9 L26 13"
            stroke={done || active ? '#D4A84F' : 'rgba(212,168,79,0.40)'}
            strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round"
            style={{ filter: active ? 'drop-shadow(0 0 4px rgba(212,168,79,0.6))' : 'none' }}/>
    </svg>
  </div>
);

/* ---------- Main Workflow component ---------- */
const Workflow = () => {
  const [activeIdx, setActiveIdx] = React.useState(0);
  const [progressMap, setProgressMap] = React.useState(() => Object.fromEntries(stages.map((_,i)=>[i, 0])));
  const tickRef = React.useRef(null);

  React.useEffect(() => {
    const STAGE_MS = 2200;
    const TICK = 80;
    let stageElapsed = 0;
    let currentStage = 0;
    setActiveIdx(0);
    setProgressMap(Object.fromEntries(stages.map((_,i)=>[i, 0])));

    tickRef.current = setInterval(() => {
      stageElapsed += TICK;
      const pct = Math.min(100, Math.round((stageElapsed / STAGE_MS) * 100));
      setProgressMap(prev => {
        const next = { ...prev };
        // ensure earlier stages stay at 100, future at 0
        for (let i = 0; i < currentStage; i++) next[i] = 100;
        next[currentStage] = pct;
        for (let i = currentStage + 1; i < stages.length; i++) next[i] = 0;
        return next;
      });
      if (stageElapsed >= STAGE_MS) {
        stageElapsed = 0;
        currentStage = currentStage + 1;
        if (currentStage >= stages.length) {
          // pause briefly, then loop
          currentStage = 0;
          setProgressMap(Object.fromEntries(stages.map((_,i)=>[i, 0])));
          setActiveIdx(0);
          return;
        }
        setActiveIdx(currentStage);
      }
    }, TICK);
    return () => clearInterval(tickRef.current);
  }, []);

  const getStatus = (i) => {
    if (i < activeIdx) return 'done';
    if (i === activeIdx) return 'active';
    return 'pending';
  };

  // Layout: top row = 0..3, bottom row reversed visually = 6,5,4 (left to right)
  const topRow = [0,1,2,3];
  const bottomRow = [6,5,4]; // displayed in this visual order

  // Proposal preview tied to stage 5 (Writer / index 4) and Quality stage 5 progress
  const writerProgress = activeIdx > 4 ? 100 : (activeIdx === 4 ? progressMap[4] : 0);

  // Active agent in panel: roughly maps stages to agents
  const stageToAgent = { 0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 0 };
  const activeAgent = stageToAgent[activeIdx];

  return (
    <div className="workflow-shell" style={{
      position: 'relative',
      borderRadius: 24,
      padding: 22,
      background: 'linear-gradient(180deg, rgba(255,255,255,0.65) 0%, rgba(255,255,255,0.45) 100%)',
      border: '1px solid rgba(255,255,255,0.7)',
      boxShadow: '0 30px 80px rgba(35,69,57,0.12), inset 0 1px 0 rgba(255,255,255,0.7)',
      backdropFilter: 'blur(24px) saturate(140%)',
      WebkitBackdropFilter: 'blur(24px) saturate(140%)',
      overflow: 'hidden'
    }}>
      {/* radial light effect */}
      <div style={{
        position: 'absolute', top: -100, left: -50,
        width: 400, height: 400,
        background: 'radial-gradient(circle, rgba(247,231,193,0.5) 0%, transparent 60%)',
        pointerEvents: 'none'
      }}/>

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18, position: 'relative' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <span style={{
            display: 'inline-flex', width: 22, height: 22,
            background: 'linear-gradient(180deg, #FBF1D8, #E0B663)',
            borderRadius: 6, alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 4px 10px rgba(212,168,79,0.3)'
          }}>
            <svg width="12" height="12" viewBox="0 0 12 12">
              <path d="M6 1l1.4 3.2L11 5l-3 2 .8 3.5L6 8.7 3.2 10.5 4 7 1 5l3.6-.8L6 1Z" fill="#2A1E08"/>
            </svg>
          </span>
          <span style={{ fontFamily: 'var(--f-display)', fontWeight: 600, fontSize: 18, color: 'var(--ink)' }}>
            Live AI Workflow
          </span>
          <span style={{ color: 'var(--muted)' }}>·</span>
          <span style={{ fontSize: 13.5, color: 'var(--ink-soft)' }}>
            Generating Proposal<DotsTyping />
          </span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            padding: '6px 12px',
            background: 'rgba(255,255,255,0.7)',
            border: '1px solid rgba(47,93,80,0.10)',
            borderRadius: 999,
            fontSize: 12, fontWeight: 500, color: 'var(--forest-deep)'
          }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#3d7565', boxShadow: '0 0 6px #3d7565' }}/>
            In Progress
          </span>
          <span style={{
            width: 30, height: 30, borderRadius: 8,
            background: 'rgba(255,255,255,0.7)',
            border: '1px solid rgba(47,93,80,0.10)',
            display: 'grid', placeItems: 'center'
          }}>
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <path d="M2 12V8M6 12V4M10 12V6" stroke="#2F5D50" strokeWidth="1.5" strokeLinecap="round"/>
            </svg>
          </span>
        </div>
      </div>

      {/* Top row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 22, position: 'relative' }}>
        {topRow.map((i, pos) => (
          <div key={i} style={{ position: 'relative' }}>
            <StageCard stage={stages[i]} idx={i} progress={progressMap[i]} status={getStatus(i)} />
            {pos < 3 && <ArrowH active={activeIdx === i+1} done={activeIdx > i} />}
          </div>
        ))}
      </div>

      {/* Vertical connector on right side */}
      <div style={{
        position: 'relative', height: 22, marginTop: 0
      }}>
        <div style={{
          position: 'absolute', right: 32, top: -8, height: 38, width: 2,
          background: activeIdx > 3
            ? 'linear-gradient(180deg, #D4A84F, #D4A84F)'
            : 'linear-gradient(180deg, rgba(212,168,79,0.30), rgba(212,168,79,0.20))',
          boxShadow: activeIdx === 4 ? '0 0 8px rgba(212,168,79,0.5)' : 'none'
        }}/>
        <div style={{
          position: 'absolute', right: 32, top: 22,
          width: 12, height: 12, transform: 'translateX(50%) translateY(-50%) rotate(45deg)',
          borderRight: `2px solid ${activeIdx > 3 ? '#D4A84F' : 'rgba(212,168,79,0.40)'}`,
          borderBottom: `2px solid ${activeIdx > 3 ? '#D4A84F' : 'rgba(212,168,79,0.40)'}`,
          borderTopLeftRadius: 2
        }}/>
      </div>

      {/* Bottom row (3 cards aligned right) */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr repeat(3, 1fr)', gap: 22, position: 'relative', marginTop: 8 }}>
        <div /> {/* empty spacer to push to right */}
        {bottomRow.map((i, pos) => (
          <div key={i} style={{ position: 'relative' }}>
            <StageCard stage={stages[i]} idx={i} progress={progressMap[i]} status={getStatus(i)} />
            {pos < 2 && <ArrowH active={activeIdx === bottomRow[pos+1]} done={activeIdx > bottomRow[pos]} direction="left" />}
          </div>
        ))}
      </div>

      {/* Connector from bottom of stage 04 down then left into stage 05 */}
      {/* (Visual gold path drawn via overlay) */}
      <svg style={{
        position: 'absolute',
        top: 200, right: 0, width: '100%', height: 240,
        pointerEvents: 'none'
      }} viewBox="0 0 100 100" preserveAspectRatio="none">
        {/* purely decorative — actual arrows handled by ArrowH */}
      </svg>

      {/* Bottom dual panel */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.4fr', gap: 22, marginTop: 22 }}>
        <ProposalPreviewCard progress={writerProgress} />
        <AgentsActive activeAgent={activeAgent} />
      </div>

      {/* Floating particles inside workflow */}
      <WorkflowParticles />
    </div>
  );
};

/* Dots typing animation in header */
const DotsTyping = () => {
  const [n, setN] = React.useState(0);
  React.useEffect(() => {
    const id = setInterval(() => setN(v => (v+1) % 4), 400);
    return () => clearInterval(id);
  }, []);
  return <span style={{ display: 'inline-block', width: 14 }}>{'.'.repeat(n)}</span>;
};

const WorkflowParticles = () => {
  const particles = React.useMemo(() => {
    return Array.from({ length: 18 }, () => ({
      left: Math.random() * 100,
      delay: Math.random() * 8,
      duration: 6 + Math.random() * 6,
      size: 1.5 + Math.random() * 2.5,
      opacity: 0.25 + Math.random() * 0.4
    }));
  }, []);
  return (
    <div style={{
      position: 'absolute', inset: 0, pointerEvents: 'none', overflow: 'hidden',
      borderRadius: 24
    }}>
      {particles.map((p, i) => (
        <span key={i} className="particle" style={{
          left: `${p.left}%`,
          bottom: -10,
          width: p.size, height: p.size,
          opacity: p.opacity,
          animationDuration: `${p.duration}s`,
          animationDelay: `${p.delay}s`
        }}/>
      ))}
    </div>
  );
};

Object.assign(window, { Workflow });
