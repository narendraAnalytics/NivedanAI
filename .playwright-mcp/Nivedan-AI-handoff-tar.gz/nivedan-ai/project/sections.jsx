/* ============================================
   Below-the-fold sections
   ============================================ */

/* ---------- PROBLEM / SOLUTION ---------- */
const ProblemSolution = () => {
  const before = [
  "Sales managers read 40-page RFPs manually — 3 hours just to understand",
  "Writing starts from a blank Google Doc, copy-pasting from old proposals",
  "Pinging 5 teammates: \"What was that case study from last year?\"",
  "Proposal feels generic — barely addresses the client's situation",
  "Reviewer finds missing sections — entire rewrite needed",
  "8–20 hours of senior staff time wasted per proposal"];

  const after = [
  "Upload an RFP — agents parse every requirement in 60 seconds",
  "Client Research Agent finds the company's latest news and priorities",
  "Past case studies retrieved from your knowledge base automatically",
  "Every section is tailored to that specific client's context",
  "Quality Review Agent checks every requirement before export",
  "Complete proposal ready in 15–20 minutes — zero hours of human writing"];


  return (
    <section className="section" id="problem">
      <div className="container">
        <div className="section-head reveal">
          <span className="eyebrow"><span className="dot" />THE REAL-WORLD PROBLEM</span>
          <h2 style={{ marginTop: 18 }}>
            The way teams write proposals today is <span className="text-gradient-gold">broken.</span>
          </h2>
          <p>One software agency handles 15 RFPs a month — that's up to 300 hours of senior staff time, every month, on work that should take minutes.</p>
        </div>

        <div style={{
          display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 28
        }} className="ba-grid">
          {/* BEFORE */}
          <div className="reveal" style={{
            position: 'relative',
            background: '#fff',
            border: '1px solid var(--line-strong)',
            borderRadius: 22,
            padding: '28px 28px 32px',
            boxShadow: 'var(--shadow-card)'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
              <span style={{
                width: 36, height: 36, borderRadius: 10,
                background: 'rgba(180, 70, 50, 0.08)',
                color: '#b44632',
                display: 'grid', placeItems: 'center', fontWeight: 700, fontSize: 18
              }}>✕</span>
              <div>
                <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--muted)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>Before</div>
                <div style={{ fontFamily: 'var(--f-display)', fontWeight: 600, fontSize: 20, color: 'var(--ink)' }}>The status quo</div>
              </div>
            </div>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: 12 }}>
              {before.map((b, i) =>
              <li key={i} style={{
                display: 'flex', gap: 12, alignItems: 'flex-start',
                padding: '12px 14px',
                background: 'rgba(180, 70, 50, 0.04)',
                borderRadius: 10,
                fontSize: 14.5, color: 'var(--ink-soft)',
                lineHeight: 1.45
              }}>
                  <span style={{
                  flexShrink: 0, marginTop: 2,
                  width: 18, height: 18, borderRadius: 6,
                  background: 'rgba(180, 70, 50, 0.12)',
                  color: '#b44632',
                  display: 'grid', placeItems: 'center', fontSize: 11, fontWeight: 700
                }}>✕</span>
                  {b}
                </li>
              )}
            </ul>
          </div>

          {/* AFTER */}
          <div className="reveal d1" style={{
            position: 'relative',
            background: 'linear-gradient(180deg, #fff 0%, var(--sage-soft) 100%)',
            border: '1px solid rgba(47, 93, 80, 0.18)',
            borderRadius: 22,
            padding: '28px 28px 32px',
            boxShadow: '0 12px 32px rgba(47, 93, 80, 0.08)'
          }}>
            {/* gold accent corner */}
            <div style={{
              position: 'absolute', top: 0, right: 0, width: 120, height: 120,
              background: 'radial-gradient(circle at top right, rgba(212,168,79,0.18), transparent 70%)',
              borderRadius: 22, pointerEvents: 'none'
            }} />
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18, position: 'relative' }}>
              <span style={{
                width: 36, height: 36, borderRadius: 10,
                background: 'var(--forest)', color: '#fff',
                display: 'grid', placeItems: 'center'
              }}>
                <svg width="18" height="18" viewBox="0 0 18 18"><path d="M3 9l4 4 8-8" stroke="#fff" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" /></svg>
              </span>
              <div>
                <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--forest)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>After Nivedan AI</div>
                <div style={{ fontFamily: 'var(--f-display)', fontWeight: 600, fontSize: 20, color: 'var(--ink)' }}>The autonomous way</div>
              </div>
            </div>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: 12 }}>
              {after.map((a, i) =>
              <li key={i} style={{
                display: 'flex', gap: 12, alignItems: 'flex-start',
                padding: '12px 14px',
                background: 'rgba(255,255,255,0.7)',
                border: '1px solid rgba(47, 93, 80, 0.08)',
                borderRadius: 10,
                fontSize: 14.5, color: 'var(--ink)',
                lineHeight: 1.45
              }}>
                  <span style={{
                  flexShrink: 0, marginTop: 2,
                  width: 18, height: 18, borderRadius: 6,
                  background: 'var(--forest)',
                  color: '#fff',
                  display: 'grid', placeItems: 'center'
                }}>
                    <svg width="10" height="10" viewBox="0 0 10 10"><path d="M2 5l2 2 4-4" stroke="#fff" strokeWidth="1.6" fill="none" strokeLinecap="round" strokeLinejoin="round" /></svg>
                  </span>
                  {a}
                </li>
              )}
            </ul>
          </div>
        </div>

        {/* Highlight pill */}
        <div className="reveal d2" style={{
          marginTop: 36,
          padding: '22px 28px',
          background: 'linear-gradient(120deg, #FBF1D8 0%, #F7E7C1 100%)',
          border: '1px solid rgba(212, 168, 79, 0.40)',
          borderRadius: 18,
          display: 'flex', alignItems: 'center', gap: 18,
          boxShadow: '0 12px 32px rgba(212,168,79,0.18)'
        }}>
          <div style={{
            width: 48, height: 48, borderRadius: 14,
            background: 'linear-gradient(180deg, #E0B663, #B88A2F)',
            display: 'grid', placeItems: 'center',
            boxShadow: '0 6px 14px rgba(212,168,79,0.35)'
          }}>
            <svg width="22" height="22" viewBox="0 0 22 22">
              <path d="M11 2 L13 8 H19 L14 12 L16 18 L11 14 L6 18 L8 12 L3 8 H9 Z" fill="#2A1E08" />
            </svg>
          </div>
          <p style={{ fontSize: 16, color: 'var(--ink)', lineHeight: 1.5, fontWeight: 500, margin: 0 }}>
            A software agency winning just <strong style={{ color: 'var(--forest-deep)' }}>one extra contract per month</strong> with Nivedan AI earns an additional <strong style={{ color: 'var(--forest-deep)' }}>₹25–₹50 lakhs annually.</strong> The subscription pays for itself in the first hour of use.
          </p>
        </div>
      </div>
    </section>);

};

/* ---------- SIX AGENTS ---------- */
const agentsList = [
{ n: "01", name: "Orchestrator Agent", role: "The Brain · Root ADK Agent", model: "gemini-3.1-pro-preview",
  desc: "Manages the entire pipeline. Creates session state, routes downstream agents, handles failures gracefully — the conductor that ensures all six instruments play in the right order.",
  icon: "shield" },
{ n: "02", name: "RFP Parser Agent", role: "Document Intelligence · Requirement Extractor", model: "gemini-3.1-flash-lite",
  desc: "Reads the entire RFP — no matter how long, no matter how messy — and extracts mandatory requirements, budget ceilings, timelines, evaluation criteria, and compliance flags.",
  icon: "doc" },
{ n: "03", name: "Client Research Agent", role: "Company Intelligence · Context Builder", model: "gemini-3.1-flash-lite",
  desc: "Researches the client's recent news, funding, leadership changes, product launches, and strategic priorities — so every proposal feels deeply informed.",
  icon: "research" },
{ n: "04", name: "Requirements Matcher Agent", role: "Capability Alignment · Proof Finder", model: "gemini-3.1-flash-lite",
  desc: "Compares what the client needs against what you actually offer. Mines your knowledge base for the strongest evidence and maps every requirement to a proof point.",
  icon: "match" },
{ n: "05", name: "Proposal Writer Agent", role: "Full Document Drafter · Section Builder", model: "gemini-3.1-pro-preview",
  desc: "The core creative agent. Writes the full proposal from Executive Summary through Pricing — every sentence written with this specific client in mind.",
  icon: "write" },
{ n: "06", name: "Quality Review & Export Agent", role: "Editor · Validator · PDF Generator", model: "gemini-3.1-flash-lite",
  desc: "Senior-editor pass. Validates every mandatory requirement is addressed, fixes conflicts, then exports a clean, branded PDF ready for submission.",
  icon: "export" }];


const AgentIcon = ({ name }) => {
  const map = {
    shield: <IconShieldSm />, doc: <IconDocSm />, research: <IconResearchSm />,
    match: <IconMatchSm />, write: <IconWriteSm />, export: <IconExportSm />
  };
  return map[name];
};
const IconShieldSm = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M12 3l8 3v6c0 4.5-3.5 8-8 9-4.5-1-8-4.5-8-9V6l8-3Z" stroke="#2F5D50" strokeWidth="1.4" /><path d="M8 12l3 3 5-5" stroke="#2F5D50" strokeWidth="1.6" fill="none" strokeLinecap="round" strokeLinejoin="round" /></svg>;
const IconDocSm = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M6 3h9l4 4v14H6V3Z" stroke="#2F5D50" strokeWidth="1.4" /><path d="M15 3v4h4M9 12h6M9 16h6M9 8h3" stroke="#2F5D50" strokeWidth="1.4" strokeLinecap="round" /></svg>;
const IconResearchSm = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="6" stroke="#2F5D50" strokeWidth="1.4" /><path d="M15.5 15.5L20 20" stroke="#2F5D50" strokeWidth="1.6" strokeLinecap="round" /><path d="M8 11h6M11 8v6" stroke="#2F5D50" strokeWidth="1.2" strokeLinecap="round" /></svg>;
const IconMatchSm = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="7" height="7" rx="1.4" stroke="#2F5D50" strokeWidth="1.4" /><rect x="14" y="3" width="7" height="7" rx="1.4" stroke="#2F5D50" strokeWidth="1.4" /><rect x="3" y="14" width="7" height="7" rx="1.4" stroke="#2F5D50" strokeWidth="1.4" /><rect x="14" y="14" width="7" height="7" rx="1.4" stroke="#2F5D50" strokeWidth="1.4" /><path d="M10 6.5h4M6.5 10v4M17.5 10v4M10 17.5h4" stroke="#D4A84F" strokeWidth="1.4" strokeLinecap="round" /></svg>;
const IconWriteSm = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M3 21l4-1 13-13-3-3L4 17l-1 4Z" stroke="#2F5D50" strokeWidth="1.4" strokeLinejoin="round" /><path d="M15 6l3 3" stroke="#2F5D50" strokeWidth="1.4" /></svg>;
const IconExportSm = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M6 3h9l4 4v14H6V3Z" stroke="#2F5D50" strokeWidth="1.4" /><path d="M15 3v4h4" stroke="#2F5D50" strokeWidth="1.4" /><text x="12" y="18" textAnchor="middle" fontSize="6" fontWeight="700" fill="#2F5D50" fontFamily="Inter">PDF</text></svg>;

const AgentCard = ({ a, i }) =>
<div className={`reveal d${i % 3 + 1}`} style={{
  position: 'relative',

  border: '1px solid var(--line-strong)',
  borderRadius: 20,
  padding: '24px 24px 26px',
  transition: 'transform .35s cubic-bezier(.2,.7,.2,1), box-shadow .35s, border-color .35s',
  overflow: 'hidden', background: "rgb(255, 255, 255)"
}}
onMouseEnter={(e) => {
  e.currentTarget.style.transform = 'translateY(-4px)';
  e.currentTarget.style.boxShadow = '0 24px 50px rgba(35,69,57,0.12)';
  e.currentTarget.style.borderColor = 'rgba(212,168,79,0.4)';
}}
onMouseLeave={(e) => {
  e.currentTarget.style.transform = 'translateY(0)';
  e.currentTarget.style.boxShadow = 'none';
  e.currentTarget.style.borderColor = 'var(--line-strong)';
}}>
    <div style={{
    position: 'absolute', top: -60, right: -60, width: 180, height: 180,
    background: 'radial-gradient(circle, rgba(247,231,193,0.40) 0%, transparent 60%)',
    pointerEvents: 'none', opacity: 0, transition: 'opacity .4s'
  }} className="agent-glow" />

    <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 18 }}>
      <div style={{
      width: 48, height: 48, borderRadius: 14,
      background: 'linear-gradient(180deg, var(--sage-soft), var(--sage))',
      display: 'grid', placeItems: 'center',
      border: '1px solid rgba(47, 93, 80, 0.12)'
    }}>
        <AgentIcon name={a.icon} />
      </div>
      <span style={{
      fontFamily: 'var(--f-display)', fontWeight: 600, fontSize: 13,
      color: 'var(--gold-deep)', letterSpacing: '0.02em',
      background: 'rgba(247, 231, 193, 0.5)', padding: '4px 10px', borderRadius: 8
    }}>{a.n}</span>
    </div>

    <h3 style={{ fontSize: 20, marginBottom: 4, color: 'var(--ink)' }}>{a.name}</h3>
    <div style={{
    fontSize: 11, fontWeight: 600, color: 'var(--forest)',
    textTransform: 'uppercase', letterSpacing: '0.10em',
    marginBottom: 12
  }}>{a.role}</div>
    <p style={{ fontSize: 14.5, lineHeight: 1.55, color: 'var(--ink-soft)', marginBottom: 18 }}>{a.desc}</p>
    <div style={{
    display: 'inline-flex', alignItems: 'center', gap: 6,
    padding: '5px 10px',
    background: 'var(--ivory-warm)',
    borderRadius: 6,
    fontSize: 11, fontFamily: 'var(--f-mono)',
    color: 'var(--ink-soft)'
  }}>
      <span style={{ width: 5, height: 5, borderRadius: '50%', background: 'var(--gold)' }} />
      {a.model}
    </div>
  </div>;


const Agents = () =>
<section className="section" id="agents" style={{
  background: 'linear-gradient(180deg, transparent 0%, rgba(221, 231, 216, 0.25) 30%, transparent 100%)'
}}>
    <div className="container">
      <div className="section-head reveal">
        <span className="eyebrow"><span className="dot" />SIX SPECIALIZED AGENTS</span>
        <h2 style={{ marginTop: 18 }}>
          One pipeline. Six instruments. <span className="text-gradient-gold">Played in perfect order.</span>
        </h2>
        <p>Each agent has one clearly defined job — and passes its structured output to the next, building your proposal layer by layer.</p>
      </div>

      <div style={{
      display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 24
    }} className="agents-grid">
        {agentsList.map((a, i) => <AgentCard key={i} a={a} i={i} />)}
      </div>
    </div>
  </section>;


/* ---------- HOW IT WORKS — sticky scroll workflow ---------- */
const steps = [
{ n: "01", agent: "Orchestrator", title: "Session initialized", desc: "Reads file metadata, creates a session with job ID and company profile, decides the execution sequence." },
{ n: "02", agent: "RFP Parser", title: "Requirements extracted", desc: "Converts a chaotic 40-page document into a clean JSON object — mandatory vs optional, budgets, timelines, evaluation weights." },
{ n: "03", agent: "Client Research", title: "Client intelligence gathered", desc: "Web research surfaces recent news, funding rounds, strategic priorities — the context that makes proposals feel custom." },
{ n: "04", agent: "Requirements Matcher", title: "Capabilities mapped", desc: "Every requirement linked to your strongest proof point from past case studies, certifications, and team bios." },
{ n: "05", agent: "Proposal Writer", title: "Full proposal drafted", desc: "Executive Summary through Pricing — every sentence tailored to the client's mission, constraints, and language." },
{ n: "06", agent: "Quality Review", title: "Validated &amp; exported", desc: "Senior-editor pass catches conflicts. Exports a branded PDF and emails it. Saved to your library, instantly." }];


const StickyWorkflow = () => {
  const [activeStep, setActiveStep] = React.useState(0);
  const stepsRef = React.useRef([]);

  React.useEffect(() => {
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          const idx = Number(e.target.dataset.idx);
          setActiveStep(idx);
        }
      });
    }, { rootMargin: '-45% 0px -45% 0px', threshold: 0 });
    stepsRef.current.forEach((el) => el && obs.observe(el));
    return () => obs.disconnect();
  }, []);

  return (
    <section className="section" id="how" style={{ paddingTop: 60 }}>
      <div className="container">
        <div className="section-head reveal">
          <span className="eyebrow"><span className="dot" />END-TO-END WORKFLOW</span>
          <h2 style={{ marginTop: 18 }}>From RFP upload to a <span className="text-gradient-gold">submission-ready PDF</span></h2>
          <p>Watch the pipeline as the document flows from one agent to the next.</p>
        </div>

        <div style={{
          display: 'grid', gridTemplateColumns: '1.05fr 1fr', gap: 80,
          alignItems: 'flex-start'
        }} className="sticky-grid">
          {/* LEFT — scrolling steps */}
          <div>
            {steps.map((s, i) =>
            <div key={i}
            ref={(el) => stepsRef.current[i] = el}
            data-idx={i}
            style={{
              minHeight: '70vh',
              display: 'flex',
              alignItems: 'center',
              paddingRight: 20
            }}>
                <div style={{
                opacity: activeStep === i ? 1 : 0.32,
                transform: activeStep === i ? 'translateX(0)' : 'translateX(-16px)',
                transition: 'all .6s cubic-bezier(.2,.7,.2,1)'
              }}>
                  <div style={{
                  display: 'inline-flex', alignItems: 'center', gap: 10,
                  padding: '6px 14px',
                  background: activeStep === i ? 'linear-gradient(180deg, #FBF1D8, #F7E7C1)' : 'var(--sage-soft)',
                  border: `1px solid ${activeStep === i ? 'rgba(212,168,79,0.4)' : 'var(--line-strong)'}`,
                  borderRadius: 999,
                  fontSize: 12, fontWeight: 600, color: 'var(--forest-deep)',
                  letterSpacing: '0.06em'
                }}>
                    <span>STEP {s.n}</span>
                    <span style={{ opacity: 0.4 }}>·</span>
                    <span>{s.agent}</span>
                  </div>
                  <h3 style={{ fontSize: 'clamp(28px, 3.5vw, 42px)', lineHeight: 1.1, margin: '20px 0 14px', textWrap: 'balance' }}
                dangerouslySetInnerHTML={{ __html: s.title }} />
                  <p style={{ fontSize: 17, color: 'var(--ink-soft)', lineHeight: 1.55, maxWidth: 520, textWrap: 'pretty' }}>{s.desc}</p>
                </div>
              </div>
            )}
          </div>

          {/* RIGHT — sticky visualization */}
          <div style={{ position: 'sticky', top: 120, alignSelf: 'flex-start' }}>
            <StickyVisualization step={activeStep} />
          </div>
        </div>
      </div>
    </section>);

};

const StickyVisualization = ({ step }) => {
  return (
    <div style={{
      borderRadius: 24,
      padding: 28,
      background: 'linear-gradient(180deg, rgba(255,255,255,0.85) 0%, rgba(250,247,242,0.7) 100%)',
      border: '1px solid rgba(255,255,255,0.7)',
      boxShadow: 'var(--shadow-card-lg)',
      backdropFilter: 'blur(20px)',
      WebkitBackdropFilter: 'blur(20px)',
      minHeight: 480,
      position: 'relative',
      overflow: 'hidden'
    }}>
      <div style={{
        position: 'absolute', top: -80, right: -80, width: 240, height: 240,
        background: 'radial-gradient(circle, rgba(247,231,193,0.5), transparent 65%)',
        pointerEvents: 'none'
      }} />

      {/* Document moving thru pipeline visualization */}
      <div style={{ position: 'relative', height: 420, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
        {/* Vertical pipeline */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
          {steps.map((s, i) =>
          <div key={i} style={{
            display: 'flex', alignItems: 'center', gap: 16,
            padding: '12px 0',
            position: 'relative'
          }}>
              <div style={{
              width: 36, height: 36, borderRadius: '50%',
              background: i <= step ?
              'linear-gradient(180deg, #FBF1D8, #E0B663)' :
              'rgba(255,255,255,0.85)',
              border: i <= step ?
              '1.5px solid rgba(212,168,79,0.5)' :
              '1px solid var(--line-strong)',
              display: 'grid', placeItems: 'center',
              fontFamily: 'var(--f-display)', fontWeight: 600,
              color: i <= step ? '#2A1E08' : 'var(--muted)',
              fontSize: 13,
              boxShadow: i === step ? '0 0 0 6px rgba(247,231,193,0.4), 0 0 16px rgba(212,168,79,0.4)' : 'none',
              transition: 'all .5s ease',
              flexShrink: 0, zIndex: 2
            }}>{s.n}</div>
              <div style={{
              fontFamily: 'var(--f-display)', fontWeight: i <= step ? 600 : 500,
              fontSize: 14.5,
              color: i === step ? 'var(--forest-deep)' : i < step ? 'var(--ink)' : 'var(--muted)',
              transition: 'color .4s ease'
            }}>{s.agent}</div>
              <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 8 }}>
                {i < step &&
              <span style={{
                width: 18, height: 18, borderRadius: '50%',
                background: 'var(--forest)', display: 'grid', placeItems: 'center'
              }}>
                    <svg width="10" height="10" viewBox="0 0 10 10"><path d="M2 5l2 2 4-4" stroke="#fff" strokeWidth="1.6" fill="none" strokeLinecap="round" strokeLinejoin="round" /></svg>
                  </span>
              }
                {i === step &&
              <span style={{ fontSize: 11, color: 'var(--gold-deep)', fontWeight: 600 }}>
                    Processing<DotsTyping />
                  </span>
              }
              </div>
              {i < steps.length - 1 &&
            <div style={{
              position: 'absolute', left: 18, top: 48, width: 2, height: 20,
              background: i < step ? 'var(--gold)' : 'rgba(212,168,79,0.20)',
              transition: 'background .4s ease', zIndex: 1
            }} />
            }
            </div>
          )}
        </div>

        {/* Final output card when reached end */}
        <div style={{
          marginTop: 12,
          padding: '14px 16px',
          background: step >= steps.length - 1 ?
          'linear-gradient(120deg, #FBF1D8, #F7E7C1)' :
          'rgba(255,255,255,0.6)',
          border: `1px solid ${step >= steps.length - 1 ? 'rgba(212,168,79,0.45)' : 'var(--line-strong)'}`,
          borderRadius: 12,
          display: 'flex', alignItems: 'center', gap: 12,
          transition: 'all .5s ease',
          opacity: step >= steps.length - 1 ? 1 : 0.55
        }}>
          <div style={{
            width: 36, height: 44, borderRadius: 4,
            background: '#fff', border: '1px solid rgba(47,93,80,0.15)',
            display: 'grid', placeItems: 'center',
            boxShadow: '0 3px 8px rgba(35,69,57,0.08)'
          }}>
            <span style={{ fontFamily: 'var(--f-mono)', fontSize: 9, fontWeight: 700, color: 'var(--forest-deep)' }}>PDF</span>
          </div>
          <div>
            <div style={{ fontFamily: 'var(--f-display)', fontWeight: 600, fontSize: 14, color: 'var(--ink)' }}>
              Proposal_Apollo_v1.pdf
            </div>
            <div style={{ fontSize: 12, color: 'var(--ink-soft)' }}>
              {step >= steps.length - 1 ? 'Ready · 12 sections · 32 pages · sent to your inbox' : 'Awaiting completion…'}
            </div>
          </div>
        </div>
      </div>
    </div>);

};

/* ---------- BENEFITS / STATS ---------- */
const useCountUp = (target, active, duration = 1200) => {
  const [val, setVal] = React.useState(0);
  React.useEffect(() => {
    if (!active) return;
    let start = null;
    let raf;
    const animate = (ts) => {
      if (!start) start = ts;
      const p = Math.min(1, (ts - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(target * eased);
      if (p < 1) raf = requestAnimationFrame(animate);
    };
    raf = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(raf);
  }, [target, active, duration]);
  return val;
};

const StatBig = ({ value, suffix = "", label, desc, active }) => {
  const isNumeric = typeof value === 'number';
  const v = useCountUp(isNumeric ? value : 0, active);
  return (
    <div style={{
      padding: '32px 28px',
      background: 'linear-gradient(180deg, rgba(255,255,255,0.7) 0%, rgba(255,255,255,0.45) 100%)',
      border: '1px solid var(--line-strong)',
      borderRadius: 20,
      backdropFilter: 'blur(8px)',
      WebkitBackdropFilter: 'blur(8px)',
      transition: 'transform .35s, box-shadow .35s, border-color .35s'
    }}
    onMouseEnter={(e) => {
      e.currentTarget.style.transform = 'translateY(-4px)';
      e.currentTarget.style.boxShadow = '0 18px 40px rgba(35,69,57,0.10)';
      e.currentTarget.style.borderColor = 'rgba(212,168,79,0.4)';
    }}
    onMouseLeave={(e) => {
      e.currentTarget.style.transform = 'translateY(0)';
      e.currentTarget.style.boxShadow = 'none';
      e.currentTarget.style.borderColor = 'var(--line-strong)';
    }}>
      <div className="text-gradient-gold" style={{
        fontFamily: 'var(--f-display)', fontWeight: 600,
        fontSize: 'clamp(40px, 4.5vw, 64px)', lineHeight: 1,
        letterSpacing: '-0.03em',
        marginBottom: 14
      }}>
        {isNumeric ? Math.round(v) : value}{suffix}
      </div>
      <div style={{ fontFamily: 'var(--f-display)', fontWeight: 600, fontSize: 17, marginBottom: 8, color: 'var(--ink)' }}>{label}</div>
      <p style={{ fontSize: 14, color: 'var(--ink-soft)', lineHeight: 1.5 }}>{desc}</p>
    </div>);

};

const Benefits = () => {
  const [active, setActive] = React.useState(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((e) => {if (e.isIntersecting) setActive(true);});
    }, { threshold: 0.2 });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);

  return (
    <section className="section" id="benefits" ref={ref}>
      <div className="container">
        <div className="section-head reveal">
          <span className="eyebrow"><span className="dot" />KEY BENEFITS</span>
          <h2 style={{ marginTop: 18 }}>The numbers behind <span className="text-gradient-gold">winning more.</span></h2>
          <p>Same team. 3× the bids. Twice the win rate. Zero missed requirements.</p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 24 }} className="benefits-grid">
          <div className="reveal"><StatBig value={95} suffix="%" label="Time Reduction" desc="From 8–20 hours per proposal down to 15–20 minutes. Senior staff reclaim hundreds of hours monthly." active={active} /></div>
          <div className="reveal d1"><StatBig value="2×" label="Higher Win Rate" desc="Tailored, research-backed proposals convert at 40–50% — double the industry average of 20–25%." active={active} /></div>
          <div className="reveal d2"><StatBig value="3×" label="More Bids Submitted" desc="The same team capacity handles 3× more RFPs per month — without hiring additional headcount." active={active} /></div>
          <div className="reveal d3"><StatBig value={0} label="Missed Requirements" desc="The Quality Review Agent checks every mandatory item before export. Nothing gets missed." active={active} /></div>
          <div className="reveal d4"><StatBig value="₹0" label="Extra Infrastructure" desc="A single Next.js monorepo on Vercel. No separate backend, no extra servers, minimal overhead." active={active} /></div>
          <div className="reveal d5"><StatBig value="∞" label="Knowledge Retention" desc="Every approved proposal is stored — and becomes part of the knowledge base making the next one smarter." active={active} /></div>
        </div>
      </div>
    </section>);

};

/* ---------- WHO USES NIVEDAN ---------- */
const audiences = [
{ name: "Software Agencies", desc: "Agencies responding to 10–15 RFPs per month from enterprise clients, hospitals, government, and corporates.", price: "₹16,000 – ₹25,000 /mo", icon: "building" },
{ name: "Freelance Developers", desc: "Bidders on Upwork, Toptal, and direct clients who need professional proposals before competitors do.", price: "₹8,000 – ₹12,000 /mo", icon: "briefcase" },
{ name: "SaaS Sales Teams", desc: "Enterprise teams responding to security RFPs and Fortune 500 questionnaires. Each deal is worth crores.", price: "₹25,000 – ₹40,000 /mo", icon: "chart" },
{ name: "Consulting Firms", desc: "Management and IT consultants for whom proposal writing is the core business cost. Cut it by 90%.", price: "₹25,000 – ₹40,000 /mo", icon: "compass" },
{ name: "Construction & Infra", desc: "Companies bidding on complex government tenders — roads, buildings, utilities — where a missed clause disqualifies the bid.", price: "₹12,000 – ₹20,000 /mo", icon: "infra" },
{ name: "EdTech & Research", desc: "Universities and research orgs applying for government grants, partnerships, and EdTech procurement contracts.", price: "₹8,000 – ₹16,000 /mo", icon: "academic" }];


const AudienceIcon = ({ name }) => {
  const map = {
    building: <path d="M4 21V8l8-4 8 4v13M9 21v-7h6v7M9 11h6" stroke="#2F5D50" strokeWidth="1.4" fill="none" strokeLinejoin="round" />,
    briefcase: <><rect x="3" y="7" width="18" height="13" rx="2" stroke="#2F5D50" strokeWidth="1.4" fill="none" /><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 13h18" stroke="#2F5D50" strokeWidth="1.4" fill="none" /></>,
    chart: <path d="M4 20V4M4 20h16M8 16V10M12 16V7M16 16V13" stroke="#2F5D50" strokeWidth="1.4" fill="none" strokeLinecap="round" />,
    compass: <><circle cx="12" cy="12" r="9" stroke="#2F5D50" strokeWidth="1.4" fill="none" /><path d="M14.5 9.5L11 13l-2 5 5-2 3.5-3.5-3-3Z" stroke="#2F5D50" strokeWidth="1.4" fill="none" strokeLinejoin="round" /></>,
    infra: <path d="M3 20h18M6 20V10l6-5 6 5v10M10 20v-6h4v6" stroke="#2F5D50" strokeWidth="1.4" fill="none" strokeLinejoin="round" />,
    academic: <><path d="M2 9l10-5 10 5-10 5L2 9Z" stroke="#2F5D50" strokeWidth="1.4" fill="none" strokeLinejoin="round" /><path d="M6 11v5c0 1 3 3 6 3s6-2 6-3v-5M22 9v6" stroke="#2F5D50" strokeWidth="1.4" fill="none" strokeLinecap="round" /></>
  };
  return <svg width="22" height="22" viewBox="0 0 24 24">{map[name]}</svg>;
};

const Audience = () =>
<section className="section" id="audience" style={{
  background: 'linear-gradient(180deg, transparent 0%, var(--ivory-warm) 50%, transparent 100%)'
}}>
    <div className="container">
      <div className="section-head reveal">
        <span className="eyebrow"><span className="dot" />WHO USES NIVEDAN AI</span>
        <h2 style={{ marginTop: 18 }}>Built for teams that <span className="text-gradient-gold">live and breathe RFPs.</span></h2>
        <p>From solo freelancers to consulting firms running 30 bids a quarter.</p>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 22 }} className="audience-grid">
        {audiences.map((a, i) =>
      <div key={i} className={`reveal d${i % 3 + 1}`} style={{
        padding: '24px 24px 26px',
        background: '#fff',
        border: '1px solid var(--line-strong)',
        borderRadius: 18,
        transition: 'transform .3s, box-shadow .3s, border-color .3s'
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.transform = 'translateY(-3px)';
        e.currentTarget.style.boxShadow = '0 18px 38px rgba(35,69,57,0.10)';
        e.currentTarget.style.borderColor = 'rgba(212,168,79,0.35)';
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.transform = 'translateY(0)';
        e.currentTarget.style.boxShadow = 'none';
        e.currentTarget.style.borderColor = 'var(--line-strong)';
      }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
              <div style={{
            width: 42, height: 42, borderRadius: 12,
            background: 'var(--sage-soft)',
            border: '1px solid rgba(47, 93, 80, 0.10)',
            display: 'grid', placeItems: 'center'
          }}>
                <AudienceIcon name={a.icon} />
              </div>
              <h3 style={{ fontSize: 17 }}>{a.name}</h3>
            </div>
            <p style={{ fontSize: 14, color: 'var(--ink-soft)', lineHeight: 1.5, marginBottom: 16 }}>{a.desc}</p>
            <div style={{
          display: 'inline-block', padding: '6px 12px',
          background: 'var(--ivory-warm)',
          borderRadius: 6,
          fontSize: 12, fontWeight: 600, color: 'var(--forest-deep)',
          fontFamily: 'var(--f-mono)'
        }}>{a.price}</div>
          </div>
      )}
      </div>
    </div>
  </section>;


/* ---------- CTA + FOOTER ---------- */
const FinalCTA = () =>
<section className="section" id="cta" style={{ paddingBottom: 80 }}>
    <div className="container">
      <div className="reveal" style={{
      position: 'relative',
      padding: '72px 56px',
      borderRadius: 28,
      background: 'linear-gradient(135deg, var(--forest-deep) 0%, var(--forest) 60%, #3d7565 100%)',
      color: '#fff',
      overflow: 'hidden',
      boxShadow: '0 30px 80px rgba(35,69,57,0.30)'
    }}>
        {/* radial gold accents */}
        <div style={{
        position: 'absolute', top: -120, right: -120, width: 460, height: 460,
        background: 'radial-gradient(circle, rgba(212,168,79,0.40), transparent 65%)',
        pointerEvents: 'none'
      }} />
        <div style={{
        position: 'absolute', bottom: -100, left: -100, width: 360, height: 360,
        background: 'radial-gradient(circle, rgba(247,231,193,0.18), transparent 65%)',
        pointerEvents: 'none'
      }} />
        {/* wave lines */}
        <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0.18 }} viewBox="0 0 1200 400" preserveAspectRatio="none">
          {[...Array(12)].map((_, i) =>
        <path key={i} d={`M -50 ${i * 32 + 40} Q 300 ${i * 32 + 10}, 600 ${i * 32 + 60} T 1300 ${i * 32 + 30}`}
        stroke="rgba(212,168,79,0.5)" strokeWidth="0.6" fill="none" />
        )}
        </svg>

        <div style={{ position: 'relative', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 40, flexWrap: 'wrap' }}>
          <div style={{ maxWidth: 660 }}>
            <span style={{
            display: 'inline-flex', alignItems: 'center', gap: 8,
            padding: '8px 16px',
            background: 'rgba(255,255,255,0.10)',
            border: '1px solid rgba(212,168,79,0.30)',
            borderRadius: 999,
            fontSize: 11, fontWeight: 600,
            letterSpacing: '0.14em', textTransform: 'uppercase',
            color: 'var(--champagne)'
          }}>
              <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--gold)', boxShadow: '0 0 8px var(--gold)' }} />
              Ready in 20 minutes
            </span>
            <h2 style={{
            fontSize: 'clamp(36px, 4.5vw, 60px)',
            lineHeight: 1.05, letterSpacing: '-0.03em',
            marginTop: 22, marginBottom: 18,
            color: '#fff', textWrap: 'balance'
          }}>
              Win the next RFP <span className="text-gradient-gold">before</span> your competitors finish reading it.
            </h2>
            <p style={{ fontSize: 18, color: 'rgba(255,255,255,0.78)', lineHeight: 1.55, maxWidth: 560, textWrap: 'pretty' }}>
              Spin up your first proposal in under five minutes. No credit card. No infrastructure to install.
            </p>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <MagneticButton>
              <button className="btn btn-gold" style={{ padding: '16px 28px', fontSize: 16 }}>
                Start Free Trial
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                  <path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
            </MagneticButton>
            <button className="btn" style={{
            padding: '16px 28px',
            background: 'rgba(255,255,255,0.08)',
            color: '#fff',
            border: '1px solid rgba(255,255,255,0.18)',
            fontSize: 16
          }}>Book a Demo</button>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.55)', textAlign: 'center', marginTop: 4 }}>
              SOC 2 · Enterprise SSO · ISO 27001
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>;


const Footer = () =>
<footer style={{
  padding: '64px 0 32px',
  borderTop: '1px solid var(--line-strong)',
  background: 'rgba(255,255,255,0.4)'
}}>
    <div className="container">
      <div style={{
      display: 'grid',
      gridTemplateColumns: '1.4fr 1fr 1fr 1fr 1fr',
      gap: 40,
      marginBottom: 48
    }} className="footer-grid">
        <div>
          <Logo />
          <p style={{ marginTop: 18, fontSize: 14, color: 'var(--ink-soft)', maxWidth: 320, lineHeight: 1.55 }}>
            "निवेदन" — the formal submission that wins contracts. Written by AI in 20 minutes, not 20 hours.
          </p>
          <div style={{ display: 'flex', gap: 12, marginTop: 24 }}>
            {['twitter', 'linkedin', 'github'].map((s) =>
          <a key={s} href="#" style={{
            width: 36, height: 36, borderRadius: 10,
            background: 'rgba(255,255,255,0.6)',
            border: '1px solid var(--line-strong)',
            display: 'grid', placeItems: 'center',
            color: 'var(--ink-soft)',
            transition: 'all .2s'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = 'var(--forest)';
            e.currentTarget.style.color = '#fff';
            e.currentTarget.style.borderColor = 'var(--forest)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = 'rgba(255,255,255,0.6)';
            e.currentTarget.style.color = 'var(--ink-soft)';
            e.currentTarget.style.borderColor = 'var(--line-strong)';
          }}>
                <SocialIcon name={s} />
              </a>
          )}
          </div>
        </div>
        {[
      { title: 'Product', links: ['Overview', 'Agents', 'Pricing', 'Integrations', 'Changelog'] },
      { title: 'Solutions', links: ['Agencies', 'Consulting', 'SaaS Sales', 'Government RFPs', 'Construction'] },
      { title: 'Resources', links: ['Documentation', 'API', 'Case Studies', 'Blog', 'Templates'] },
      { title: 'Company', links: ['About', 'Customers', 'Security', 'Careers', 'Contact'] }].
      map((col, i) =>
      <div key={i}>
            <div style={{
          fontFamily: 'var(--f-display)', fontWeight: 600, fontSize: 14,
          color: 'var(--ink)', marginBottom: 16
        }}>{col.title}</div>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
              {col.links.map((l, j) =>
          <li key={j}>
                  <a href="#" style={{ fontSize: 13.5, color: 'var(--ink-soft)', transition: 'color .2s' }}
            onMouseEnter={(e) => e.currentTarget.style.color = 'var(--forest-deep)'}
            onMouseLeave={(e) => e.currentTarget.style.color = 'var(--ink-soft)'}>{l}</a>
                </li>
          )}
            </ul>
          </div>
      )}
      </div>
      <div className="divider" />
      <div style={{
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      flexWrap: 'wrap', gap: 16,
      marginTop: 28,
      fontSize: 12.5, color: 'var(--muted)'
    }}>
        <div>© 2026 Nivedan AI · Built with Google ADK + Gemini 3.1 + Next.js 15</div>
        <div style={{ display: 'flex', gap: 24 }}>
          <a href="#" style={{ color: 'var(--muted)' }}>Privacy</a>
          <a href="#" style={{ color: 'var(--muted)' }}>Terms</a>
          <a href="#" style={{ color: 'var(--muted)' }}>Security</a>
          <a href="#" style={{ color: 'var(--muted)' }}>Status</a>
        </div>
      </div>
    </div>
  </footer>;


const SocialIcon = ({ name }) => {
  if (name === 'twitter') return <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor"><path d="M12.5 1H15l-5.4 6.2L16 15h-5L7.2 10 2.7 15H.2l5.8-6.6L0 1h5.1l3.5 4.6L12.5 1Zm-.9 12.5h1.4L4.5 2.4H3L11.6 13.5Z" /></svg>;
  if (name === 'linkedin') return <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor"><path d="M3 6h2.5v8H3V6Zm1.3-3.5a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM7 6h2.4v1.2c.4-.7 1.4-1.3 2.6-1.3 2.8 0 3 1.8 3 4.2V14h-2.5v-3.6c0-.9 0-2-1.3-2s-1.5 1-1.5 2V14H7V6Z" /></svg>;
  if (name === 'github') return <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor"><path d="M8 0a8 8 0 0 0-2.5 15.6c.4.1.6-.2.6-.4v-1.4c-2.2.5-2.7-1-2.7-1-.4-.9-.9-1.2-.9-1.2-.7-.5 0-.5 0-.5.8 0 1.2.8 1.2.8.7 1.2 1.9.9 2.4.7.1-.5.3-.9.5-1.1-1.8-.2-3.6-.9-3.6-4 0-.9.3-1.6.8-2.1-.1-.2-.4-1 .1-2.1 0 0 .7-.2 2.2.8.6-.2 1.3-.3 2-.3.7 0 1.4.1 2 .3 1.5-1 2.2-.8 2.2-.8.5 1.1.2 1.9.1 2.1.5.5.8 1.2.8 2.1 0 3.1-1.8 3.8-3.6 4 .3.3.5.8.5 1.6V15c0 .2.2.5.6.4A8 8 0 0 0 8 0Z" /></svg>;
};

Object.assign(window, { ProblemSolution, Agents, StickyWorkflow, Benefits, Audience, FinalCTA, Footer });