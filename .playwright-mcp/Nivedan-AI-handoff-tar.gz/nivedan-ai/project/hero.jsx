/* Hero section — full-bleed cinematic */

const Hero = () => {
  const heroRef = React.useRef(null);
  const lightRef = React.useRef(null);

  // Cursor radial light
  React.useEffect(() => {
    const onMove = (e) => {
      if (!lightRef.current || !heroRef.current) return;
      const rect = heroRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      lightRef.current.style.background =
        `radial-gradient(600px 400px at ${x}px ${y}px, rgba(247, 231, 193, 0.45), transparent 60%)`;
    };
    document.addEventListener('mousemove', onMove);
    return () => document.removeEventListener('mousemove', onMove);
  }, []);

  return (
    <section ref={heroRef} id="top" style={{
      position: 'relative',
      paddingTop: 120,
      paddingBottom: 60,
      overflow: 'hidden'
    }}>
      {/* Background layers */}
      <div ref={lightRef} style={{
        position: 'absolute', inset: 0, pointerEvents: 'none', transition: 'background .3s ease'
      }}/>
      {/* Soft wave lines */}
      <svg style={{ position: 'absolute', top: 40, left: -100, width: 900, height: 800, opacity: 0.35, pointerEvents: 'none' }} viewBox="0 0 900 800" fill="none">
        {[...Array(28)].map((_, i) => (
          <path key={i}
            d={`M -100 ${50 + i*28} Q 200 ${20 + i*28}, 500 ${80 + i*28} T 1000 ${60 + i*28}`}
            stroke={i % 4 === 0 ? "rgba(212,168,79,0.18)" : "rgba(47,93,80,0.06)"}
            strokeWidth="1" fill="none"/>
        ))}
      </svg>
      {/* Decorative stars/sparkles */}
      <Sparkles />

      <div className="container" style={{ position: 'relative' }}>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'minmax(0, 0.95fr) minmax(0, 1.2fr)',
          gap: 56,
          alignItems: 'center'
        }} className="hero-grid">

          {/* LEFT */}
          <div>
            <div className="reveal in">
              <span className="eyebrow">
                <SparkleIcon />
                AUTONOMOUS PROPOSAL INTELLIGENCE PLATFORM
              </span>
            </div>

            <h1 className="reveal in d1" style={{
              marginTop: 28,
              fontSize: 'clamp(44px, 5.4vw, 78px)',
              lineHeight: 1.02,
              letterSpacing: '-0.035em',
              fontWeight: 600,
              textWrap: 'balance'
            }}>
              <span style={{ color: 'var(--forest)' }}>Proposals that win.</span><br/>
              <span style={{ color: 'var(--forest)' }}>Written by </span>
              <span className="text-gradient-gold">AI</span>
              <span style={{ color: 'var(--forest)' }}>,</span><br/>
              <span className="text-gradient-gold">in 20 minutes.</span>
            </h1>

            <p className="reveal in d2" style={{
              marginTop: 28,
              fontSize: 18,
              lineHeight: 1.55,
              color: 'var(--ink-soft)',
              maxWidth: 520,
              textWrap: 'pretty'
            }}>
              Nivedan AI deploys six specialized AI agents to research, write,
              review, and perfect RFP responses that are tailored, compliant,
              and ready to win.
            </p>

            <div className="reveal in d3" style={{ display: 'flex', gap: 14, marginTop: 36, flexWrap: 'wrap' }}>
              <MagneticButton>
                <button className="btn btn-primary" style={{ padding: '15px 26px' }}>
                  Start Free Trial
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </button>
              </MagneticButton>
              <button className="btn btn-ghost" style={{ padding: '15px 22px' }}>
                <span style={{
                  width: 22, height: 22, borderRadius: '50%',
                  background: 'var(--gold)', display: 'grid', placeItems: 'center'
                }}>
                  <svg width="9" height="9" viewBox="0 0 10 10"><path d="M3 2 L8 5 L3 8 Z" fill="#2A1E08"/></svg>
                </span>
                See How It Works
              </button>
            </div>

            {/* Social proof row */}
            <div className="reveal in d4" style={{ display: 'flex', alignItems: 'center', gap: 18, marginTop: 36 }}>
              <AvatarStack />
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <Stars />
                  <span style={{ fontFamily: 'var(--f-display)', fontWeight: 600, color: 'var(--ink)', fontSize: 14 }}>4.9/5</span>
                </div>
                <div style={{ fontSize: 13, color: 'var(--ink-soft)', marginTop: 2 }}>
                  Trusted by 250+ agencies &amp; enterprises worldwide
                </div>
              </div>
            </div>

            {/* Stat tiles */}
            <div className="reveal in d5" style={{
              display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12,
              marginTop: 36
            }}>
              <StatTile icon={<TimeIcon />} value="95%" label="Time Reduction" />
              <StatTile icon={<StackIcon />} value="3×" label="More Proposals" />
              <StatTile icon={<TrophyIcon />} value="40–50%" label="Higher Win Rate" />
              <StatTile icon={<EnterpriseIcon />} value="Enterprise" label="Secure & Scalable" />
            </div>
          </div>

          {/* RIGHT — Workflow */}
          <div className="reveal in d2" style={{ position: 'relative' }}>
            <Workflow />
          </div>
        </div>
      </div>

      {/* Trusted strip — bottom of hero */}
      <div style={{ marginTop: 80, position: 'relative' }}>
        <TrustedStrip />
      </div>
    </section>
  );
};

/* ------- mini components ------- */

const SparkleIcon = () => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
    <path d="M7 1l1.2 3.5L12 6 8.2 7.5 7 11 5.8 7.5 2 6l3.8-1.5L7 1Z" fill="#D4A84F"/>
  </svg>
);

const Stars = () => (
  <div style={{ display: 'flex', gap: 3 }}>
    {[0,1,2,3,4].map(i => (
      <svg key={i} width="14" height="14" viewBox="0 0 14 14">
        <path d="M7 1l1.7 4 4.3.4-3.3 2.8 1 4.3L7 10.3 3.3 12.5l1-4.3L1 5.4 5.3 5 7 1Z" fill="#D4A84F"/>
      </svg>
    ))}
  </div>
);

const AvatarStack = () => {
  // soft gradient circles with stylized silhouettes — no real photos to avoid representation issues
  const colors = [
    ['#E5C57A','#2F5D50'],
    ['#D4A84F','#234539'],
    ['#3d7565','#FBF1D8'],
    ['#2F5D50','#F0DBA6']
  ];
  return (
    <div style={{ display: 'flex' }}>
      {colors.map((c, i) => (
        <div key={i} style={{
          width: 38, height: 38, borderRadius: '50%',
          background: `linear-gradient(135deg, ${c[0]}, ${c[1]})`,
          border: '2.5px solid var(--ivory)',
          marginLeft: i === 0 ? 0 : -10,
          position: 'relative', overflow: 'hidden',
          boxShadow: '0 4px 10px rgba(35,69,57,0.12)'
        }}>
          {/* silhouette */}
          <svg viewBox="0 0 38 38" style={{ width: '100%', height: '100%', position: 'absolute', inset: 0 }}>
            <circle cx="19" cy="15" r="6" fill="rgba(255,255,255,0.3)"/>
            <ellipse cx="19" cy="30" rx="11" ry="8" fill="rgba(255,255,255,0.3)"/>
          </svg>
        </div>
      ))}
    </div>
  );
};

const StatTile = ({ icon, value, label }) => (
  <div style={{
    background: 'linear-gradient(180deg, rgba(255,255,255,0.7) 0%, rgba(255,255,255,0.5) 100%)',
    border: '1px solid var(--line-strong)',
    borderRadius: 14,
    padding: '14px 14px',
    display: 'flex', flexDirection: 'column', gap: 6,
    backdropFilter: 'blur(8px)',
    WebkitBackdropFilter: 'blur(8px)',
    transition: 'transform .25s, box-shadow .25s',
    cursor: 'default'
  }}
  onMouseEnter={e => {
    e.currentTarget.style.transform = 'translateY(-2px)';
    e.currentTarget.style.boxShadow = '0 12px 28px rgba(35,69,57,0.10)';
  }}
  onMouseLeave={e => {
    e.currentTarget.style.transform = 'translateY(0)';
    e.currentTarget.style.boxShadow = 'none';
  }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      {icon}
      <span style={{ fontFamily: 'var(--f-display)', fontWeight: 600, fontSize: 18, color: 'var(--forest-deep)' }}>{value}</span>
    </div>
    <div style={{ fontSize: 12, color: 'var(--muted)', fontWeight: 500 }}>{label}</div>
  </div>
);

const TimeIcon = () => (
  <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
    <circle cx="9" cy="9" r="7" stroke="#D4A84F" strokeWidth="1.4"/>
    <path d="M9 5v4l3 2" stroke="#D4A84F" strokeWidth="1.4" strokeLinecap="round"/>
  </svg>
);
const StackIcon = () => (
  <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
    <path d="M9 2 L16 5 L9 8 L2 5 Z" stroke="#D4A84F" strokeWidth="1.4" strokeLinejoin="round"/>
    <path d="M2 9 L9 12 L16 9" stroke="#D4A84F" strokeWidth="1.4" strokeLinejoin="round"/>
    <path d="M2 13 L9 16 L16 13" stroke="#D4A84F" strokeWidth="1.4" strokeLinejoin="round"/>
  </svg>
);
const TrophyIcon = () => (
  <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
    <path d="M5 3 H13 V7 a4 4 0 0 1-8 0 Z" stroke="#D4A84F" strokeWidth="1.4" strokeLinejoin="round"/>
    <path d="M5 5 H3 a2 2 0 0 0 2 3M13 5 H15 a2 2 0 0 1-2 3" stroke="#D4A84F" strokeWidth="1.4"/>
    <path d="M7 15 H11 M9 11 V15" stroke="#D4A84F" strokeWidth="1.4" strokeLinecap="round"/>
  </svg>
);
const EnterpriseIcon = () => (
  <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
    <rect x="3" y="6" width="6" height="9" stroke="#D4A84F" strokeWidth="1.4"/>
    <rect x="9" y="3" width="6" height="12" stroke="#D4A84F" strokeWidth="1.4"/>
    <path d="M5 9h2M5 12h2M11 6h2M11 9h2M11 12h2" stroke="#D4A84F" strokeWidth="1.2" strokeLinecap="round"/>
  </svg>
);

const Sparkles = () => {
  const sparkles = React.useMemo(() => Array.from({ length: 14 }, () => ({
    top: Math.random() * 70 + 5,
    left: Math.random() * 95,
    size: 4 + Math.random() * 8,
    delay: Math.random() * 4,
    duration: 3 + Math.random() * 3
  })), []);
  return (
    <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
      {sparkles.map((s, i) => (
        <div key={i} style={{
          position: 'absolute',
          top: `${s.top}%`, left: `${s.left}%`,
          width: s.size, height: s.size,
          background: 'var(--gold)',
          borderRadius: '50%',
          opacity: 0.3,
          boxShadow: `0 0 ${s.size * 2}px rgba(212,168,79,0.6)`,
          animation: `twinkle ${s.duration}s ease-in-out ${s.delay}s infinite`
        }}/>
      ))}
    </div>
  );
};

/* Trusted by strip — original fictional enterprise wordmarks */
const TrustedStrip = () => {
  const brands = [
    { name: "MERIDIAN",  style: { fontFamily: 'var(--f-display)', fontWeight: 700, letterSpacing: '-0.02em' } },
    { name: "Northwind", style: { fontFamily: 'Georgia, serif', fontStyle: 'italic', fontWeight: 600 } },
    { name: "ATLAS·CO", style: { fontFamily: 'var(--f-mono)', fontWeight: 600, letterSpacing: '0.04em' } },
    { name: "Lumenex",  style: { fontFamily: 'var(--f-display)', fontWeight: 500, letterSpacing: '0.18em', textTransform: 'uppercase' } },
    { name: "VANGARD",   style: { fontFamily: 'var(--f-display)', fontWeight: 700, letterSpacing: '0.04em' } },
    { name: "Helios",    style: { fontFamily: 'Georgia, serif', fontWeight: 700 } },
    { name: "QUORUM",    style: { fontFamily: 'var(--f-display)', fontWeight: 800, letterSpacing: '-0.02em' } },
    { name: "Saffron Labs", style: { fontFamily: 'var(--f-display)', fontWeight: 600, letterSpacing: '-0.01em' } },
  ];
  return (
    <div className="container">
      <div style={{
        padding: '32px 32px',
        borderRadius: 18,
        background: 'linear-gradient(180deg, rgba(255,255,255,0.65) 0%, rgba(255,255,255,0.4) 100%)',
        border: '1px solid rgba(255,255,255,0.6)',
        backdropFilter: 'blur(10px)',
        WebkitBackdropFilter: 'blur(10px)'
      }}>
        <div style={{ textAlign: 'center', marginBottom: 22 }}>
          <span style={{
            display: 'inline-flex', alignItems: 'center', gap: 16,
            fontSize: 11, fontWeight: 600,
            color: 'var(--muted)', letterSpacing: '0.18em', textTransform: 'uppercase'
          }}>
            <span style={{ width: 32, height: 1, background: 'var(--line-strong)' }}/>
            Trusted by forward-thinking teams
            <span style={{ width: 32, height: 1, background: 'var(--line-strong)' }}/>
          </span>
        </div>
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          flexWrap: 'wrap', gap: 28
        }}>
          {brands.map((b, i) => (
            <div key={i} style={{
              ...b.style,
              fontSize: 22,
              color: 'rgba(47, 93, 80, 0.55)',
              transition: 'color .25s, transform .25s',
              cursor: 'default'
            }}
            onMouseEnter={e => { e.currentTarget.style.color = 'var(--forest-deep)'; e.currentTarget.style.transform = 'translateY(-1px)'; }}
            onMouseLeave={e => { e.currentTarget.style.color = 'rgba(47, 93, 80, 0.55)'; e.currentTarget.style.transform = 'translateY(0)'; }}>
              {b.name}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

Object.assign(window, { Hero });
